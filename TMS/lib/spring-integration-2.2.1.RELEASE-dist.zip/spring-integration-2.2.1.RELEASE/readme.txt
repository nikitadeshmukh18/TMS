SPRING INTEGRATION 2.1.0
------------------------

To find out what has changed since any earlier releases, see 'changelog.txt'.

Please consult the documentation located within the 'docs/reference' directory
of this release and also visit the official Spring Integration home at
http://www.springsource.org/spring-integration

There you will find links to the forum, issue tracker, and several other resources.

See https://github.com/SpringSource/spring-integration#readme for additional
information including instructions on building from source.
